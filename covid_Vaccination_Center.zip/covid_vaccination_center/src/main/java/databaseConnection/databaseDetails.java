package databaseConnection;

public interface databaseDetails {
	public static final String DATABASE_DRIVER = "com.mysql.cj.jdbc.Driver";
	public static final String DATABASE_URL = "jdbc:mysql://localhost:3306/vaccinationCenter";
	public static final String DATABASE_USER = "root";
	public static final String DATABASE_PASS = "Mukul@123";
}
